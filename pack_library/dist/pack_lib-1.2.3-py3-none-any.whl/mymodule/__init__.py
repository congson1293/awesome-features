from mymodule.mymodule import read_value
